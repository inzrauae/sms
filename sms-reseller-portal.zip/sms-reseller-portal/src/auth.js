'use strict';

const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { db } = require('./db');

const COOKIE = 'sid';
const TOKEN_TTL = '7d';

function secret() {
  const value = process.env.SESSION_SECRET;
  if (!value || value.length < 16) {
    throw new Error('SESSION_SECRET must be set to a random string of 16+ characters.');
  }
  return value;
}

const hashPassword = (plain) => bcrypt.hash(plain, 12);
const verifyPassword = (plain, hash) => bcrypt.compare(plain, hash);

function issueSession(res, user) {
  const token = jwt.sign({ sub: user.id, role: user.role }, secret(), { expiresIn: TOKEN_TTL });
  res.cookie(COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 7 * 24 * 60 * 60 * 1000,
  });
}

const clearSession = (res) => res.clearCookie(COOKIE);

function currentUser(req) {
  const token = req.cookies && req.cookies[COOKIE];
  if (!token) return null;
  try {
    const claims = jwt.verify(token, secret());
    const user = db
      .prepare(
        `SELECT id, uid, name, company, email, phone, role, status, credits, rate, created_at
         FROM users WHERE id = ?`
      )
      .get(claims.sub);
    if (!user || user.status !== 'active') return null;
    return user;
  } catch {
    return null;
  }
}

/** Gate for dashboard JSON endpoints. */
function requireAuth(req, res, next) {
  const user = currentUser(req);
  if (!user) return res.status(401).json({ status: 'error', message: 'Sign in to continue.' });
  req.user = user;
  next();
}

function requireAdmin(req, res, next) {
  const user = currentUser(req);
  if (!user) return res.status(401).json({ status: 'error', message: 'Sign in to continue.' });
  if (user.role !== 'admin') {
    return res.status(403).json({ status: 'error', message: 'Admins only.' });
  }
  req.user = user;
  next();
}

/* ------------------------------------------------------------ API tokens */

/**
 * Tokens look like `47|9f3c...`, mirroring the Text.lk format so customers can
 * point an existing integration at this portal by changing the base URL alone.
 * Only the hash is stored; the plaintext is shown once at creation.
 */
function createApiToken(userId, name) {
  const rawSecret = crypto.randomBytes(24).toString('hex');
  const row = db
    .prepare('INSERT INTO api_tokens (user_id, name, prefix, token_hash) VALUES (?, ?, ?, ?)')
    .run(userId, name || 'Default token', 'pending', 'pending');

  const id = row.lastInsertRowid;
  const plaintext = `${id}|${rawSecret}`;
  const hash = crypto.createHash('sha256').update(rawSecret).digest('hex');

  db.prepare('UPDATE api_tokens SET prefix = ?, token_hash = ? WHERE id = ?').run(
    rawSecret.slice(0, 6),
    hash,
    id
  );

  return { id, plaintext, prefix: rawSecret.slice(0, 6) };
}

function resolveApiToken(bearer) {
  if (!bearer) return null;
  const value = String(bearer).trim();
  const separator = value.indexOf('|');
  if (separator < 1) return null;

  const id = Number(value.slice(0, separator));
  const rawSecret = value.slice(separator + 1);
  if (!Number.isInteger(id) || !rawSecret) return null;

  const record = db.prepare('SELECT * FROM api_tokens WHERE id = ? AND revoked = 0').get(id);
  if (!record) return null;

  const hash = crypto.createHash('sha256').update(rawSecret).digest('hex');
  const a = Buffer.from(hash);
  const b = Buffer.from(record.token_hash);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(record.user_id);
  if (!user || user.status !== 'active') return null;

  db.prepare("UPDATE api_tokens SET last_used_at = datetime('now') WHERE id = ?").run(record.id);
  return { user, token: record };
}

/** Gate for the public REST API consumed by tenants' own applications. */
function requireApiToken(req, res, next) {
  const header = req.get('authorization') || '';
  const bearer = header.toLowerCase().startsWith('bearer ') ? header.slice(7) : null;
  const resolved = resolveApiToken(bearer);

  if (!resolved) {
    return res.status(401).json({
      status: 'error',
      message: 'Invalid or missing API token.',
    });
  }

  req.user = resolved.user;
  req.apiToken = resolved.token;
  next();
}

module.exports = {
  COOKIE,
  hashPassword,
  verifyPassword,
  issueSession,
  clearSession,
  currentUser,
  requireAuth,
  requireAdmin,
  createApiToken,
  requireApiToken,
};
