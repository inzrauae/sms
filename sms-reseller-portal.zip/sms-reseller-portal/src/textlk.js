'use strict';

/**
 * Text.lk v3 client.
 *
 * One upstream account funds the whole portal, so this token never leaves the
 * server. Per-tenant isolation is enforced in our own database, not here.
 */

const BASE_URL = (process.env.TEXTLK_BASE_URL || 'https://app.text.lk/api/v3').replace(/\/+$/, '');
const TIMEOUT_MS = Number(process.env.TEXTLK_TIMEOUT_MS || 20000);

class TextLkError extends Error {
  constructor(message, { status, body } = {}) {
    super(message);
    this.name = 'TextLkError';
    this.status = status;
    this.body = body;
  }
}

function token() {
  const value = process.env.TEXTLK_API_TOKEN;
  if (!value) {
    throw new TextLkError('TEXTLK_API_TOKEN is not set. Add it to your .env file.');
  }
  return value;
}

async function request(method, endpoint, { body, query, retries = 1 } = {}) {
  let url = `${BASE_URL}${endpoint}`;
  if (query) {
    const params = new URLSearchParams();
    for (const [key, value] of Object.entries(query)) {
      if (value !== undefined && value !== null && value !== '') params.append(key, value);
    }
    const qs = params.toString();
    if (qs) url += `?${qs}`;
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      method,
      signal: controller.signal,
      headers: {
        Authorization: `Bearer ${token()}`,
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: body ? JSON.stringify(body) : undefined,
    });

    const text = await response.text();
    let payload;
    try {
      payload = text ? JSON.parse(text) : {};
    } catch {
      payload = { raw: text };
    }

    if (!response.ok) {
      // Retry once on upstream 5xx — but never on a send, because a timeout
      // does not prove the message was not accepted.
      if (response.status >= 500 && retries > 0 && method === 'GET') {
        return request(method, endpoint, { body, query, retries: retries - 1 });
      }
      throw new TextLkError(
        payload.message || `Text.lk responded with ${response.status}`,
        { status: response.status, body: payload }
      );
    }

    if (payload && payload.status === 'error') {
      throw new TextLkError(payload.message || 'Text.lk rejected the request.', {
        status: response.status,
        body: payload,
      });
    }

    return payload;
  } catch (err) {
    if (err.name === 'AbortError') {
      throw new TextLkError('Text.lk did not respond in time.', { status: 504 });
    }
    if (err instanceof TextLkError) throw err;
    throw new TextLkError(`Could not reach Text.lk: ${err.message}`);
  } finally {
    clearTimeout(timer);
  }
}

/* ---------------------------------------------------------------- profile */

const getBalance = () => request('GET', '/balance');
const getProfile = () => request('GET', '/me');

/* ------------------------------------------------------------------- sms */

/**
 * @param {object} p
 * @param {string} p.recipient   comma separated msisdns
 * @param {string} p.sender_id   approved mask
 * @param {string} p.type        plain | unicode
 * @param {string} p.message
 * @param {string} [p.schedule_time]  'Y-m-d H:i'
 * @param {string} [p.dlt_template_id]
 */
function sendSms(p) {
  const body = {
    recipient: p.recipient,
    sender_id: p.sender_id,
    type: p.type || 'plain',
    message: p.message,
  };
  if (p.schedule_time) body.schedule_time = p.schedule_time;
  if (p.dlt_template_id) body.dlt_template_id = p.dlt_template_id;
  return request('POST', '/sms/send', { body, retries: 0 });
}

/**
 * Campaign send against a stored contact group.
 * The published docs list `contact_list_id` in the parameter table but use
 * `recipient` in the sample payload, so both keys go out. Harmless either way.
 */
function sendCampaign(p) {
  const body = {
    contact_list_id: p.contact_list_id,
    recipient: p.contact_list_id,
    sender_id: p.sender_id,
    type: p.type || 'plain',
    message: p.message,
  };
  if (p.schedule_time) body.schedule_time = p.schedule_time;
  if (p.dlt_template_id) body.dlt_template_id = p.dlt_template_id;
  return request('POST', '/sms/campaign', { body, retries: 0 });
}

const viewSms = (uid) => request('GET', `/sms/${encodeURIComponent(uid)}`);
const listSms = (query = {}) => request('GET', '/sms', { query });
const viewCampaign = (uid) => request('GET', `/campaign/${encodeURIComponent(uid)}/view`);

/* -------------------------------------------------------- contact groups */

const listGroups = () => request('GET', '/contacts');
const createGroup = (name) => request('POST', '/contacts', { body: { name } });
const showGroup = (groupId) => request('POST', `/contacts/${encodeURIComponent(groupId)}/show`);
const updateGroup = (groupId, name) =>
  request('PATCH', `/contacts/${encodeURIComponent(groupId)}`, { body: { name } });
const deleteGroup = (groupId) => request('DELETE', `/contacts/${encodeURIComponent(groupId)}`);

/* --------------------------------------------------------------- contacts */

const listContacts = (groupId, page = 1) =>
  request('POST', `/contacts/${encodeURIComponent(groupId)}/all`, { query: { page } });

const createContact = (groupId, fields) =>
  request('POST', `/contacts/${encodeURIComponent(groupId)}/store`, { body: fields });

const showContact = (groupId, contactUid) =>
  request('POST', `/contacts/${encodeURIComponent(groupId)}/search/${encodeURIComponent(contactUid)}`);

const updateContact = (groupId, contactUid, fields) =>
  request('PATCH', `/contacts/${encodeURIComponent(groupId)}/update/${encodeURIComponent(contactUid)}`, {
    body: fields,
  });

const deleteContact = (groupId, contactUid) =>
  request('DELETE', `/contacts/${encodeURIComponent(groupId)}/delete/${encodeURIComponent(contactUid)}`);

/** Pull the first `uid`-looking value out of a loosely typed response. */
function extractUid(payload) {
  const data = payload && payload.data;
  if (!data || typeof data !== 'object') return null;
  if (data.uid) return data.uid;
  if (data.data && data.data.uid) return data.data.uid;
  if (Array.isArray(data) && data[0] && data[0].uid) return data[0].uid;
  return null;
}

module.exports = {
  TextLkError,
  BASE_URL,
  getBalance,
  getProfile,
  sendSms,
  sendCampaign,
  viewSms,
  listSms,
  viewCampaign,
  listGroups,
  createGroup,
  showGroup,
  updateGroup,
  deleteGroup,
  listContacts,
  createContact,
  showContact,
  updateContact,
  deleteContact,
  extractUid,
};
