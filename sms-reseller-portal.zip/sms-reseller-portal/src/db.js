'use strict';

const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const Database = require('better-sqlite3');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });

const db = new Database(path.join(DATA_DIR, 'portal.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  uid           TEXT UNIQUE NOT NULL,
  name          TEXT NOT NULL,
  company       TEXT,
  email         TEXT UNIQUE NOT NULL,
  phone         TEXT,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'user',
  status        TEXT NOT NULL DEFAULT 'active',
  credits       INTEGER NOT NULL DEFAULT 0,
  rate          REAL    NOT NULL DEFAULT 1.10,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sender_ids (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  mask       TEXT NOT NULL,
  status     TEXT NOT NULL DEFAULT 'pending',
  note       TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (user_id, mask)
);

CREATE TABLE IF NOT EXISTS messages (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  uid           TEXT UNIQUE NOT NULL,
  provider_uid  TEXT,
  user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  campaign_id   INTEGER REFERENCES campaigns(id) ON DELETE SET NULL,
  recipient     TEXT NOT NULL,
  sender_id     TEXT NOT NULL,
  body          TEXT NOT NULL,
  sms_type      TEXT NOT NULL DEFAULT 'plain',
  segments      INTEGER NOT NULL DEFAULT 1,
  units         INTEGER NOT NULL DEFAULT 1,
  cost          REAL NOT NULL DEFAULT 0,
  status        TEXT NOT NULL DEFAULT 'Queued',
  source        TEXT NOT NULL DEFAULT 'dashboard',
  error         TEXT,
  scheduled_at  TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_messages_user ON messages(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_status ON messages(status);

CREATE TABLE IF NOT EXISTS campaigns (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  uid          TEXT UNIQUE NOT NULL,
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name         TEXT,
  group_uid    TEXT NOT NULL,
  group_name   TEXT,
  sender_id    TEXT NOT NULL,
  body         TEXT NOT NULL,
  sms_type     TEXT NOT NULL DEFAULT 'plain',
  contacts     INTEGER NOT NULL DEFAULT 0,
  units        INTEGER NOT NULL DEFAULT 0,
  cost         REAL NOT NULL DEFAULT 0,
  status       TEXT NOT NULL DEFAULT 'Queued',
  provider_ref TEXT,
  scheduled_at TEXT,
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Contact groups live on Text.lk, but Text.lk sees one account: ours.
-- This table is what keeps tenant A from reading tenant B's groups.
CREATE TABLE IF NOT EXISTS groups (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider_uid TEXT UNIQUE NOT NULL,
  name         TEXT NOT NULL,
  contacts     INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS transactions (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type          TEXT NOT NULL,
  units         INTEGER NOT NULL,
  balance_after INTEGER NOT NULL,
  amount        REAL NOT NULL DEFAULT 0,
  note          TEXT,
  ref           TEXT,
  actor         TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_tx_user ON transactions(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS api_tokens (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name         TEXT NOT NULL,
  prefix       TEXT NOT NULL,
  token_hash   TEXT NOT NULL,
  last_used_at TEXT,
  revoked      INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_tokens_prefix ON api_tokens(prefix);

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT
);
`);

const uid = () => crypto.randomBytes(6).toString('hex');

const settings = {
  get(key, fallback = null) {
    const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
    return row ? row.value : fallback;
  },
  set(key, value) {
    db.prepare(
      'INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value'
    ).run(key, String(value));
  },
  all() {
    return Object.fromEntries(
      db.prepare('SELECT key, value FROM settings').all().map((r) => [r.key, r.value])
    );
  },
};

/**
 * Move credits and write the ledger entry in one transaction.
 * `units` is positive to add, negative to take away. Throws when the user
 * cannot cover a debit, which is what stops an oversell.
 */
const adjustCredits = db.transaction((userId, units, meta = {}) => {
  const user = db.prepare('SELECT id, credits, rate FROM users WHERE id = ?').get(userId);
  if (!user) throw new Error('User not found');

  const next = user.credits + units;
  if (next < 0) {
    const err = new Error('Not enough credits for this send.');
    err.code = 'INSUFFICIENT_CREDITS';
    err.available = user.credits;
    err.required = Math.abs(units);
    throw err;
  }

  db.prepare('UPDATE users SET credits = ? WHERE id = ?').run(next, userId);
  db.prepare(
    `INSERT INTO transactions (user_id, type, units, balance_after, amount, note, ref, actor)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    userId,
    meta.type || (units >= 0 ? 'topup' : 'debit'),
    units,
    next,
    meta.amount != null ? meta.amount : Math.abs(units) * (user.rate || 0),
    meta.note || null,
    meta.ref || null,
    meta.actor || null
  );

  return next;
});

function balanceOf(userId) {
  const row = db.prepare('SELECT credits FROM users WHERE id = ?').get(userId);
  return row ? row.credits : 0;
}

module.exports = { db, uid, settings, adjustCredits, balanceOf, DATA_DIR };
