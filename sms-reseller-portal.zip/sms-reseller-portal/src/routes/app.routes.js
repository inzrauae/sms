'use strict';

const express = require('express');
const { db, uid, adjustCredits } = require('../db');
const auth = require('../auth');
const sms = require('../sms');
const textlk = require('../textlk');
const dispatch = require('../dispatch');

const router = express.Router();
router.use(auth.requireAuth);

const fail = (res, status, message, extra = {}) =>
  res.status(status).json({ status: 'error', message, ...extra });

function handleDispatchError(res, err) {
  if (err instanceof dispatch.DispatchError) {
    const status = err.code === 'INSUFFICIENT_CREDITS' ? 402 : 422;
    return res
      .status(status)
      .json({ status: 'error', code: err.code, message: err.message, required: err.required, available: err.available });
  }
  throw err;
}

/* --------------------------------------------------------------- overview */

router.get('/overview', (req, res) => {
  const userId = req.user.id;

  const totals = db
    .prepare(
      `SELECT
         COUNT(*)                                                   AS total,
         COALESCE(SUM(units), 0)                                    AS units,
         SUM(CASE WHEN status = 'Delivered' THEN 1 ELSE 0 END)      AS delivered,
         SUM(CASE WHEN status IN ('Failed','Rejected','Undelivered') THEN 1 ELSE 0 END) AS failed,
         SUM(CASE WHEN status IN ('Queued','Sent','Pending','Scheduled') THEN 1 ELSE 0 END) AS pending
       FROM messages WHERE user_id = ?`
    )
    .get(userId);

  const month = db
    .prepare(
      `SELECT COUNT(*) AS sent, COALESCE(SUM(units),0) AS units, COALESCE(SUM(cost),0) AS cost
       FROM messages WHERE user_id = ? AND created_at >= date('now','start of month')`
    )
    .get(userId);

  const daily = db
    .prepare(
      `SELECT date(created_at) AS day, COUNT(*) AS count
       FROM messages
       WHERE user_id = ? AND created_at >= date('now','-13 days')
       GROUP BY day ORDER BY day`
    )
    .all(userId);

  const recent = db
    .prepare(
      `SELECT uid, recipient, sender_id, body, status, segments, units, created_at
       FROM messages WHERE user_id = ? ORDER BY id DESC LIMIT 8`
    )
    .all(userId);

  const senders = db
    .prepare('SELECT mask, status FROM sender_ids WHERE user_id = ? ORDER BY mask')
    .all(userId);

  res.json({
    status: 'success',
    data: {
      credits: req.user.credits,
      rate: req.user.rate,
      totals,
      month,
      daily,
      recent,
      senders,
      groups: db.prepare('SELECT COUNT(*) AS n FROM groups WHERE user_id = ?').get(userId).n,
    },
  });
});

/* ---------------------------------------------------------------- compose */

// Live segment counter for the composer. Cheap, local, no upstream call.
router.post('/preview', (req, res) => {
  const analysis = sms.analyse(String(req.body.message || ''));
  const { valid, invalid } = sms.parseRecipients(req.body.recipients || '');
  const units = analysis.segments * Math.max(valid.length, 1);
  res.json({
    status: 'success',
    data: {
      ...analysis,
      recipients: valid.length,
      invalid,
      units,
      cost: Number((units * req.user.rate).toFixed(2)),
      affordable: units <= req.user.credits,
    },
  });
});

router.post('/send', async (req, res, next) => {
  try {
    const result = await dispatch.sendToNumbers({
      user: req.user,
      recipients: req.body.recipients,
      senderId: String(req.body.sender_id || '').trim(),
      message: req.body.message,
      scheduleTime: req.body.schedule_time,
      dltTemplateId: req.body.dlt_template_id,
      source: 'dashboard',
    });
    res.json({ status: 'success', data: { ...result, credits: db.prepare('SELECT credits FROM users WHERE id = ?').get(req.user.id).credits } });
  } catch (err) {
    try {
      handleDispatchError(res, err);
    } catch (rethrown) {
      next(rethrown);
    }
  }
});

router.post('/campaign', async (req, res, next) => {
  try {
    const result = await dispatch.sendToGroup({
      user: req.user,
      groupUid: String(req.body.group_uid || ''),
      senderId: String(req.body.sender_id || '').trim(),
      message: req.body.message,
      scheduleTime: req.body.schedule_time,
      name: req.body.name,
      source: 'dashboard',
    });
    res.json({ status: 'success', data: { ...result, credits: db.prepare('SELECT credits FROM users WHERE id = ?').get(req.user.id).credits } });
  } catch (err) {
    try {
      handleDispatchError(res, err);
    } catch (rethrown) {
      next(rethrown);
    }
  }
});

/* --------------------------------------------------------------- messages */

function messageQuery(req) {
  const clauses = ['user_id = @user_id'];
  const params = { user_id: req.user.id };

  if (req.query.status) {
    clauses.push('status = @status');
    params.status = req.query.status;
  }
  if (req.query.sender) {
    clauses.push('sender_id = @sender');
    params.sender = req.query.sender;
  }
  if (req.query.search) {
    clauses.push('(recipient LIKE @search OR body LIKE @search)');
    params.search = `%${req.query.search}%`;
  }
  if (req.query.start_date) {
    clauses.push('created_at >= @start_date');
    params.start_date = req.query.start_date;
  }
  if (req.query.end_date) {
    clauses.push('created_at <= @end_date');
    params.end_date = `${req.query.end_date} 23:59:59`.slice(0, 19);
  }
  return { where: clauses.join(' AND '), params };
}

router.get('/messages', (req, res) => {
  const { where, params } = messageQuery(req);
  const perPage = Math.min(Number(req.query.per_page) || 25, 100);
  const page = Math.max(Number(req.query.page) || 1, 1);

  const total = db.prepare(`SELECT COUNT(*) AS n FROM messages WHERE ${where}`).get(params).n;
  const rows = db
    .prepare(
      `SELECT uid, provider_uid, recipient, sender_id, body, sms_type, segments, units, cost,
              status, source, scheduled_at, created_at
       FROM messages WHERE ${where}
       ORDER BY id DESC LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: perPage, offset: (page - 1) * perPage });

  res.json({
    status: 'success',
    data: { data: rows, total, page, per_page: perPage, last_page: Math.max(Math.ceil(total / perPage), 1) },
  });
});

router.get('/messages/export', (req, res) => {
  const { where, params } = messageQuery(req);
  const rows = db
    .prepare(
      `SELECT created_at, recipient, sender_id, sms_type, segments, units, cost, status, body
       FROM messages WHERE ${where} ORDER BY id DESC LIMIT 20000`
    )
    .all(params);

  const escape = (v) => `"${String(v == null ? '' : v).replace(/"/g, '""')}"`;
  const header = 'Sent at,Recipient,Sender,Type,Segments,Credits,Cost,Status,Message';
  const body = rows
    .map((r) =>
      [r.created_at, r.recipient, r.sender_id, r.sms_type, r.segments, r.units, r.cost, r.status, r.body]
        .map(escape)
        .join(',')
    )
    .join('\n');

  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="messages-${Date.now()}.csv"`);
  res.send(`${header}\n${body}`);
});

router.post('/messages/sync', async (req, res, next) => {
  try {
    res.json({ status: 'success', data: await dispatch.syncStatuses(40) });
  } catch (err) {
    next(err);
  }
});

router.get('/campaigns', (req, res) => {
  const rows = db
    .prepare('SELECT * FROM campaigns WHERE user_id = ? ORDER BY id DESC LIMIT 50')
    .all(req.user.id);
  res.json({ status: 'success', data: rows });
});

/* ------------------------------------------------------------- sender IDs */

router.get('/senders', (req, res) => {
  res.json({
    status: 'success',
    data: db.prepare('SELECT id, mask, status, note, created_at FROM sender_ids WHERE user_id = ? ORDER BY id DESC').all(req.user.id),
  });
});

router.post('/senders', (req, res) => {
  const check = sms.validateSenderMask(req.body.mask);
  if (!check.ok) return fail(res, 422, check.error);

  const exists = db
    .prepare('SELECT id FROM sender_ids WHERE user_id = ? AND mask = ?')
    .get(req.user.id, check.value);
  if (exists) return fail(res, 409, 'You have already requested that sender name.');

  db.prepare('INSERT INTO sender_ids (user_id, mask, status) VALUES (?, ?, ?)').run(
    req.user.id,
    check.value,
    'pending'
  );
  res.status(201).json({ status: 'success', message: 'Sender name submitted for approval.' });
});

router.delete('/senders/:id', (req, res) => {
  db.prepare('DELETE FROM sender_ids WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
  res.json({ status: 'success' });
});

/* ---------------------------------------------------------------- groups */

// Groups are shared upstream, so the name sent to Text.lk is namespaced by
// tenant while the tenant keeps seeing the name they typed.
const upstreamName = (user, name) => `u${user.id}-${name}`.slice(0, 60);

router.get('/groups', (req, res) => {
  res.json({
    status: 'success',
    data: db.prepare('SELECT provider_uid, name, contacts, created_at FROM groups WHERE user_id = ? ORDER BY id DESC').all(req.user.id),
  });
});

router.post('/groups', async (req, res, next) => {
  try {
    const name = String(req.body.name || '').trim();
    if (name.length < 2) return fail(res, 422, 'Give the group a name.');

    const payload = await textlk.createGroup(upstreamName(req.user, name));
    const providerUid = textlk.extractUid(payload);
    if (!providerUid) {
      return fail(res, 502, 'The gateway created the group but returned no ID. Refresh and check your groups.');
    }

    db.prepare('INSERT INTO groups (user_id, provider_uid, name) VALUES (?, ?, ?)').run(
      req.user.id,
      providerUid,
      name
    );
    res.status(201).json({ status: 'success', data: { provider_uid: providerUid, name, contacts: 0 } });
  } catch (err) {
    if (err instanceof textlk.TextLkError) return fail(res, 502, err.message);
    next(err);
  }
});

function ownedGroup(req, res) {
  const group = db
    .prepare('SELECT * FROM groups WHERE provider_uid = ? AND user_id = ?')
    .get(req.params.groupUid, req.user.id);
  if (!group) {
    fail(res, 404, 'Group not found.');
    return null;
  }
  return group;
}

router.patch('/groups/:groupUid', async (req, res, next) => {
  const group = ownedGroup(req, res);
  if (!group) return;
  try {
    const name = String(req.body.name || '').trim();
    if (name.length < 2) return fail(res, 422, 'Give the group a name.');
    await textlk.updateGroup(group.provider_uid, upstreamName(req.user, name));
    db.prepare('UPDATE groups SET name = ? WHERE id = ?').run(name, group.id);
    res.json({ status: 'success' });
  } catch (err) {
    if (err instanceof textlk.TextLkError) return fail(res, 502, err.message);
    next(err);
  }
});

router.delete('/groups/:groupUid', async (req, res, next) => {
  const group = ownedGroup(req, res);
  if (!group) return;
  try {
    await textlk.deleteGroup(group.provider_uid);
    db.prepare('DELETE FROM groups WHERE id = ?').run(group.id);
    res.json({ status: 'success' });
  } catch (err) {
    if (err instanceof textlk.TextLkError) return fail(res, 502, err.message);
    next(err);
  }
});

/* --------------------------------------------------------------- contacts */

router.get('/groups/:groupUid/contacts', async (req, res, next) => {
  const group = ownedGroup(req, res);
  if (!group) return;
  try {
    const payload = await textlk.listContacts(group.provider_uid, Number(req.query.page) || 1);
    const data = payload && payload.data;
    if (data && Number.isInteger(data.total)) {
      db.prepare('UPDATE groups SET contacts = ? WHERE id = ?').run(data.total, group.id);
    }
    res.json({ status: 'success', data });
  } catch (err) {
    if (err instanceof textlk.TextLkError) return fail(res, 502, err.message);
    next(err);
  }
});

router.post('/groups/:groupUid/contacts', async (req, res, next) => {
  const group = ownedGroup(req, res);
  if (!group) return;
  try {
    const phone = sms.normaliseNumber(req.body.PHONE || req.body.phone);
    if (!phone) return fail(res, 422, 'Enter a valid phone number.');

    const fields = { PHONE: phone };
    if (req.body.FIRST_NAME) fields.FIRST_NAME = String(req.body.FIRST_NAME).trim();
    if (req.body.LAST_NAME) fields.LAST_NAME = String(req.body.LAST_NAME).trim();

    await textlk.createContact(group.provider_uid, fields);
    db.prepare('UPDATE groups SET contacts = contacts + 1 WHERE id = ?').run(group.id);
    res.status(201).json({ status: 'success' });
  } catch (err) {
    if (err instanceof textlk.TextLkError) return fail(res, 502, err.message);
    next(err);
  }
});

/** Paste-in import: one contact per line, `phone, first name, last name`. */
router.post('/groups/:groupUid/import', async (req, res, next) => {
  const group = ownedGroup(req, res);
  if (!group) return;
  try {
    const lines = String(req.body.rows || '')
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean)
      .slice(0, 500);

    if (!lines.length) return fail(res, 422, 'Paste at least one contact.');

    const added = [];
    const skipped = [];

    for (const line of lines) {
      const [rawPhone, first, last] = line.split(/[,\t]/).map((p) => (p || '').trim());
      const phone = sms.normaliseNumber(rawPhone);
      if (!phone) {
        skipped.push(line);
        continue;
      }
      const fields = { PHONE: phone };
      if (first) fields.FIRST_NAME = first;
      if (last) fields.LAST_NAME = last;
      try {
        await textlk.createContact(group.provider_uid, fields);
        added.push(phone);
      } catch {
        skipped.push(line);
      }
    }

    db.prepare('UPDATE groups SET contacts = contacts + ? WHERE id = ?').run(added.length, group.id);
    res.json({ status: 'success', data: { added: added.length, skipped } });
  } catch (err) {
    next(err);
  }
});

router.delete('/groups/:groupUid/contacts/:contactUid', async (req, res, next) => {
  const group = ownedGroup(req, res);
  if (!group) return;
  try {
    await textlk.deleteContact(group.provider_uid, req.params.contactUid);
    db.prepare('UPDATE groups SET contacts = MAX(contacts - 1, 0) WHERE id = ?').run(group.id);
    res.json({ status: 'success' });
  } catch (err) {
    if (err instanceof textlk.TextLkError) return fail(res, 502, err.message);
    next(err);
  }
});

/* ------------------------------------------------------------ API tokens */

router.get('/tokens', (req, res) => {
  res.json({
    status: 'success',
    data: db
      .prepare('SELECT id, name, prefix, last_used_at, created_at FROM api_tokens WHERE user_id = ? AND revoked = 0 ORDER BY id DESC')
      .all(req.user.id),
  });
});

router.post('/tokens', (req, res) => {
  const count = db
    .prepare('SELECT COUNT(*) AS n FROM api_tokens WHERE user_id = ? AND revoked = 0')
    .get(req.user.id).n;
  if (count >= 5) return fail(res, 422, 'You can hold five active tokens. Revoke one first.');

  const token = auth.createApiToken(req.user.id, String(req.body.name || 'Default token').trim());
  res.status(201).json({
    status: 'success',
    data: { token: token.plaintext },
    message: 'Copy this token now. It will not be shown again.',
  });
});

router.delete('/tokens/:id', (req, res) => {
  db.prepare('UPDATE api_tokens SET revoked = 1 WHERE id = ? AND user_id = ?').run(
    req.params.id,
    req.user.id
  );
  res.json({ status: 'success' });
});

/* ---------------------------------------------------------------- billing */

router.get('/transactions', (req, res) => {
  res.json({
    status: 'success',
    data: db
      .prepare('SELECT type, units, balance_after, amount, note, created_at FROM transactions WHERE user_id = ? ORDER BY id DESC LIMIT 100')
      .all(req.user.id),
  });
});

/**
 * Records a credit request. Real money should move through a payment gateway;
 * this queues the request for an admin to confirm once payment clears.
 */
router.post('/topup-request', (req, res) => {
  const units = Math.floor(Number(req.body.units));
  if (!Number.isFinite(units) || units < 100) {
    return fail(res, 422, 'Request at least 100 credits.');
  }
  db.prepare(
    `INSERT INTO transactions (user_id, type, units, balance_after, amount, note, actor)
     VALUES (?, 'request', ?, ?, ?, ?, 'user')`
  ).run(req.user.id, units, req.user.credits, units * req.user.rate, req.body.note || 'Top-up requested');

  res.json({ status: 'success', message: 'Request sent. Credits appear once payment is confirmed.' });
});

/* ---------------------------------------------------------------- profile */

router.patch('/profile', (req, res) => {
  const name = String(req.body.name || '').trim();
  const company = String(req.body.company || '').trim();
  const phone = String(req.body.phone || '').trim();
  if (name.length < 2) return fail(res, 422, 'Enter your name.');

  db.prepare('UPDATE users SET name = ?, company = ?, phone = ? WHERE id = ?').run(
    name,
    company || null,
    phone || null,
    req.user.id
  );
  res.json({ status: 'success', message: 'Profile saved.' });
});

router.post('/password', async (req, res, next) => {
  try {
    const current = String(req.body.current_password || '');
    const next_ = String(req.body.new_password || '');
    if (next_.length < 8) return fail(res, 422, 'Use a password of at least 8 characters.');

    const row = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(req.user.id);
    if (!(await auth.verifyPassword(current, row.password_hash))) {
      return fail(res, 401, 'Your current password is not correct.');
    }

    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(
      await auth.hashPassword(next_),
      req.user.id
    );
    res.json({ status: 'success', message: 'Password changed.' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
