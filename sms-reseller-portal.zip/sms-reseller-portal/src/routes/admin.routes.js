'use strict';

const express = require('express');
const { db, settings, adjustCredits } = require('../db');
const auth = require('../auth');
const textlk = require('../textlk');

const router = express.Router();
router.use(auth.requireAdmin);

const fail = (res, status, message) => res.status(status).json({ status: 'error', message });

/** Pull a numeric credit balance out of the loosely typed /balance response. */
function readUpstreamUnits(payload) {
  const data = payload && payload.data;
  if (data == null) return null;
  if (typeof data === 'number') return data;
  if (typeof data === 'string') {
    const n = Number(data.replace(/[^\d.-]/g, ''));
    return Number.isFinite(n) ? n : null;
  }
  for (const key of ['remaining_sms_unit', 'sms_unit', 'remaining', 'balance', 'units', 'available']) {
    if (data[key] != null) {
      const n = Number(String(data[key]).replace(/[^\d.-]/g, ''));
      if (Number.isFinite(n)) return n;
    }
  }
  return null;
}

router.get('/overview', async (req, res) => {
  const tenants = db
    .prepare("SELECT COUNT(*) AS n, COALESCE(SUM(credits),0) AS credits FROM users WHERE role = 'user'")
    .get();

  const traffic = db
    .prepare(
      `SELECT COUNT(*) AS messages, COALESCE(SUM(units),0) AS units, COALESCE(SUM(cost),0) AS revenue
       FROM messages WHERE created_at >= date('now','start of month')`
    )
    .get();

  const pendingSenders = db
    .prepare("SELECT COUNT(*) AS n FROM sender_ids WHERE status = 'pending'")
    .get().n;

  const topupRequests = db
    .prepare("SELECT COUNT(*) AS n FROM transactions WHERE type = 'request'")
    .get().n;

  // Reconciliation: credits promised to tenants vs credits actually held
  // upstream. If sold exceeds held, the next sends will fail at the gateway.
  let upstream = null;
  let upstreamError = null;
  try {
    upstream = readUpstreamUnits(await textlk.getBalance());
  } catch (err) {
    upstreamError = err.message;
  }

  res.json({
    status: 'success',
    data: {
      tenants: tenants.n,
      credits_sold: tenants.credits,
      upstream_units: upstream,
      upstream_error: upstreamError,
      shortfall: upstream != null ? Math.min(upstream - tenants.credits, 0) : null,
      traffic,
      pending_senders: pendingSenders,
      topup_requests: topupRequests,
      settings: settings.all(),
    },
  });
});

router.get('/users', (req, res) => {
  const search = req.query.search ? `%${req.query.search}%` : null;
  const rows = search
    ? db
        .prepare(
          `SELECT id, uid, name, company, email, phone, role, status, credits, rate, created_at
           FROM users WHERE name LIKE ? OR email LIKE ? OR company LIKE ? ORDER BY id DESC`
        )
        .all(search, search, search)
    : db
        .prepare(
          `SELECT id, uid, name, company, email, phone, role, status, credits, rate, created_at
           FROM users ORDER BY id DESC`
        )
        .all();

  const stats = db
    .prepare(
      `SELECT user_id, COUNT(*) AS messages, COALESCE(SUM(units),0) AS units
       FROM messages GROUP BY user_id`
    )
    .all();
  const byUser = new Map(stats.map((s) => [s.user_id, s]));

  res.json({
    status: 'success',
    data: rows.map((u) => ({ ...u, messages: (byUser.get(u.id) || {}).messages || 0, units_used: (byUser.get(u.id) || {}).units || 0 })),
  });
});

router.post('/users/:id/credits', (req, res) => {
  const units = Math.round(Number(req.body.units));
  if (!Number.isFinite(units) || units === 0) {
    return fail(res, 422, 'Enter a number of credits to add or remove.');
  }
  const user = db.prepare('SELECT id, rate FROM users WHERE id = ?').get(req.params.id);
  if (!user) return fail(res, 404, 'User not found.');

  try {
    const balance = adjustCredits(user.id, units, {
      type: units > 0 ? 'topup' : 'adjust',
      note: req.body.note || (units > 0 ? 'Credits added by admin' : 'Credits removed by admin'),
      amount: units > 0 ? units * (user.rate || 0) : 0,
      actor: req.user.email,
    });

    // Clear any queued requests for this tenant once credits land.
    if (units > 0) {
      db.prepare("DELETE FROM transactions WHERE user_id = ? AND type = 'request'").run(user.id);
    }
    res.json({ status: 'success', data: { credits: balance } });
  } catch (err) {
    if (err.code === 'INSUFFICIENT_CREDITS') {
      return fail(res, 422, 'That would take the balance below zero.');
    }
    throw err;
  }
});

router.patch('/users/:id', (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return fail(res, 404, 'User not found.');

  const rate = req.body.rate != null ? Number(req.body.rate) : user.rate;
  const status = req.body.status || user.status;
  const role = req.body.role || user.role;

  if (!Number.isFinite(rate) || rate < 0) return fail(res, 422, 'Enter a valid rate.');
  if (!['active', 'suspended'].includes(status)) return fail(res, 422, 'Unknown status.');
  if (!['user', 'admin'].includes(role)) return fail(res, 422, 'Unknown role.');
  if (user.id === req.user.id && (status !== 'active' || role !== 'admin')) {
    return fail(res, 422, 'You cannot remove your own admin access.');
  }

  db.prepare('UPDATE users SET rate = ?, status = ?, role = ? WHERE id = ?').run(rate, status, role, user.id);
  res.json({ status: 'success' });
});

/* ------------------------------------------------------ sender approvals */

router.get('/senders', (req, res) => {
  res.json({
    status: 'success',
    data: db
      .prepare(
        `SELECT s.id, s.mask, s.status, s.note, s.created_at, u.name, u.company, u.email
         FROM sender_ids s JOIN users u ON u.id = s.user_id
         ORDER BY CASE s.status WHEN 'pending' THEN 0 ELSE 1 END, s.id DESC`
      )
      .all(),
  });
});

router.post('/senders/:id/decision', (req, res) => {
  const decision = req.body.decision;
  if (!['approved', 'rejected'].includes(decision)) return fail(res, 422, 'Unknown decision.');

  const changed = db
    .prepare('UPDATE sender_ids SET status = ?, note = ? WHERE id = ?')
    .run(decision, req.body.note || null, req.params.id);
  if (!changed.changes) return fail(res, 404, 'Sender name not found.');

  res.json({ status: 'success' });
});

/* ---------------------------------------------------------- all traffic */

router.get('/messages', (req, res) => {
  const perPage = Math.min(Number(req.query.per_page) || 50, 200);
  const page = Math.max(Number(req.query.page) || 1, 1);

  const total = db.prepare('SELECT COUNT(*) AS n FROM messages').get().n;
  const rows = db
    .prepare(
      `SELECT m.uid, m.recipient, m.sender_id, m.body, m.status, m.units, m.cost, m.source, m.created_at,
              u.name AS user_name, u.email AS user_email
       FROM messages m JOIN users u ON u.id = m.user_id
       ORDER BY m.id DESC LIMIT ? OFFSET ?`
    )
    .all(perPage, (page - 1) * perPage);

  res.json({ status: 'success', data: { data: rows, total, page, per_page: perPage } });
});

router.get('/requests', (req, res) => {
  res.json({
    status: 'success',
    data: db
      .prepare(
        `SELECT t.id, t.units, t.amount, t.note, t.created_at, u.id AS user_id, u.name, u.email, u.credits
         FROM transactions t JOIN users u ON u.id = t.user_id
         WHERE t.type = 'request' ORDER BY t.id DESC`
      )
      .all(),
  });
});

/* --------------------------------------------------------------- settings */

router.post('/settings', (req, res) => {
  const allowed = ['brand_name', 'default_rate', 'signup_bonus', 'support_email', 'currency'];
  for (const key of allowed) {
    if (req.body[key] != null) settings.set(key, req.body[key]);
  }
  res.json({ status: 'success', data: settings.all() });
});

module.exports = router;
