'use strict';

/**
 * Tenant-facing REST API.
 *
 * Deliberately mirrors the Text.lk v3 contract: a customer already integrated
 * with Text.lk can point at this portal by changing the base URL and the token.
 */

const express = require('express');
const rateLimit = require('express-rate-limit');
const { db } = require('../db');
const auth = require('../auth');
const sms = require('../sms');
const dispatch = require('../dispatch');

const router = express.Router();

router.use(
  rateLimit({
    windowMs: 60 * 1000,
    limit: Number(process.env.API_RATE_LIMIT || 120),
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: (req) => req.get('authorization') || req.ip,
    message: { status: 'error', message: 'Rate limit reached. Slow down and retry.' },
  })
);

router.use(auth.requireApiToken);

function sendError(res, err) {
  if (err instanceof dispatch.DispatchError) {
    const status = err.code === 'INSUFFICIENT_CREDITS' ? 402 : 422;
    return res.status(status).json({ status: 'error', message: err.message });
  }
  return res.status(500).json({ status: 'error', message: 'Something went wrong sending that message.' });
}

router.post('/sms/send', async (req, res) => {
  try {
    const result = await dispatch.sendToNumbers({
      user: req.user,
      recipients: req.body.recipient,
      senderId: String(req.body.sender_id || '').trim(),
      message: req.body.message,
      scheduleTime: req.body.schedule_time,
      dltTemplateId: req.body.dlt_template_id,
      source: 'api',
    });

    res.json({
      status: 'success',
      data: {
        uid: result.uids[0],
        uids: result.uids,
        to: result.recipients.join(','),
        from: String(req.body.sender_id || '').trim(),
        message: req.body.message,
        sms_type: result.encoding === 'unicode' ? 'unicode' : 'plain',
        sms_count: result.segments,
        cost: result.units,
        status: result.status,
        scheduled_at: result.scheduled_at,
      },
    });
  } catch (err) {
    sendError(res, err);
  }
});

router.post('/sms/campaign', async (req, res) => {
  try {
    const result = await dispatch.sendToGroup({
      user: req.user,
      groupUid: String(req.body.contact_list_id || req.body.recipient || ''),
      senderId: String(req.body.sender_id || '').trim(),
      message: req.body.message,
      scheduleTime: req.body.schedule_time,
      source: 'api',
    });
    res.json({ status: 'success', data: result });
  } catch (err) {
    sendError(res, err);
  }
});

router.get('/sms/:uid', (req, res) => {
  const row = db
    .prepare(
      `SELECT uid, recipient AS "to", sender_id AS "from", body AS message, sms_type,
              source AS direction, status, segments AS sms_count, units AS cost, created_at AS sent_at
       FROM messages WHERE uid = ? AND user_id = ?`
    )
    .get(req.params.uid, req.user.id);

  if (!row) return res.status(404).json({ status: 'error', message: 'No message with that ID.' });
  res.json({ status: 'success', data: row });
});

router.get('/sms', (req, res) => {
  const clauses = ['user_id = @user_id'];
  const params = { user_id: req.user.id };

  if (req.query.start_date) {
    clauses.push('created_at >= @start_date');
    params.start_date = req.query.start_date;
  }
  if (req.query.end_date) {
    clauses.push('created_at <= @end_date');
    params.end_date = req.query.end_date;
  }
  if (req.query.sms_type) {
    clauses.push('sms_type = @sms_type');
    params.sms_type = req.query.sms_type;
  }
  if (req.query.direction) {
    clauses.push('source = @direction');
    params.direction = req.query.direction;
  }

  const where = clauses.join(' AND ');
  const perPage = Math.min(Number(req.query.per_page) || 25, 100);
  const page = Math.max(Number(req.query.page) || 1, 1);
  const total = db.prepare(`SELECT COUNT(*) AS n FROM messages WHERE ${where}`).get(params).n;

  const rows = db
    .prepare(
      `SELECT uid, recipient AS "to", sender_id AS "from", body AS message, sms_type,
              source AS direction, status, segments AS sms_count, units AS cost, created_at AS sent_at
       FROM messages WHERE ${where} ORDER BY id DESC LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit: perPage, offset: (page - 1) * perPage });

  const base = `${req.protocol}://${req.get('host')}/api/v3/sms`;
  const lastPage = Math.max(Math.ceil(total / perPage), 1);

  res.json({
    status: 'success',
    message: 'SMS data fetched successfully',
    data: {
      current_page: page,
      data: rows,
      first_page_url: `${base}?page=1`,
      from: rows.length ? (page - 1) * perPage + 1 : null,
      last_page: lastPage,
      last_page_url: `${base}?page=${lastPage}`,
      next_page_url: page < lastPage ? `${base}?page=${page + 1}` : null,
      path: base,
      per_page: perPage,
      prev_page_url: page > 1 ? `${base}?page=${page - 1}` : null,
      to: rows.length ? (page - 1) * perPage + rows.length : null,
      total,
    },
  });
});

router.get('/balance', (req, res) => {
  const credits = db.prepare('SELECT credits FROM users WHERE id = ?').get(req.user.id).credits;
  res.json({
    status: 'success',
    data: { remaining_sms_unit: credits, rate: req.user.rate, currency: 'LKR' },
  });
});

router.get('/me', (req, res) => {
  res.json({
    status: 'success',
    data: {
      uid: req.user.uid,
      name: req.user.name,
      company: req.user.company,
      email: req.user.email,
      phone: req.user.phone,
      remaining_sms_unit: req.user.credits,
      status: req.user.status,
      created_at: req.user.created_at,
    },
  });
});

router.get('/contacts', (req, res) => {
  res.json({
    status: 'success',
    data: db
      .prepare('SELECT provider_uid AS uid, name, contacts FROM groups WHERE user_id = ?')
      .all(req.user.id),
  });
});

/** Utility endpoint: cost a message before committing to send it. */
router.post('/sms/estimate', (req, res) => {
  const analysis = sms.analyse(String(req.body.message || ''));
  const { valid, invalid } = sms.parseRecipients(req.body.recipient || '');
  const units = analysis.segments * Math.max(valid.length, 1);
  res.json({
    status: 'success',
    data: { ...analysis, recipients: valid.length, invalid, units, cost: units * req.user.rate },
  });
});

module.exports = router;
