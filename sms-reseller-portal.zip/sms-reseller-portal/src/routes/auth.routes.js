'use strict';

const express = require('express');
const rateLimit = require('express-rate-limit');
const { db, uid, settings, adjustCredits } = require('../db');
const auth = require('../auth');

const router = express.Router();

const attemptLimit = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 12,
  standardHeaders: true,
  legacyHeaders: false,
  message: { status: 'error', message: 'Too many attempts. Try again in a few minutes.' },
});

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

router.post('/register', attemptLimit, async (req, res, next) => {
  try {
    const name = String(req.body.name || '').trim();
    const company = String(req.body.company || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const phone = String(req.body.phone || '').trim();
    const password = String(req.body.password || '');

    if (name.length < 2) {
      return res.status(422).json({ status: 'error', message: 'Enter your name.' });
    }
    if (!EMAIL_RE.test(email)) {
      return res.status(422).json({ status: 'error', message: 'Enter a valid email address.' });
    }
    if (password.length < 8) {
      return res.status(422).json({ status: 'error', message: 'Use a password of at least 8 characters.' });
    }
    if (db.prepare('SELECT id FROM users WHERE email = ?').get(email)) {
      return res.status(409).json({ status: 'error', message: 'An account already uses that email. Sign in instead.' });
    }

    const passwordHash = await auth.hashPassword(password);
    const defaultRate = Number(settings.get('default_rate', '0.75'));

    const result = db
      .prepare(
        `INSERT INTO users (uid, name, company, email, phone, password_hash, rate)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      )
      .run(uid(), name, company || null, email, phone || null, passwordHash, defaultRate);

    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(result.lastInsertRowid);

    const bonus = Number(settings.get('signup_bonus', '10'));
    if (bonus > 0) {
      adjustCredits(user.id, bonus, {
        type: 'topup',
        note: 'Welcome credits',
        amount: 0,
        actor: 'system',
      });
    }

    auth.issueSession(res, user);
    res.status(201).json({
      status: 'success',
      data: { uid: user.uid, name: user.name, email: user.email, credits: bonus },
    });
  } catch (err) {
    next(err);
  }
});

router.post('/login', attemptLimit, async (req, res, next) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');

    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    // Always run a comparison so a missing account and a wrong password take
    // the same amount of time.
    const ok = user
      ? await auth.verifyPassword(password, user.password_hash)
      : await auth.verifyPassword(password, '$2a$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinv');

    if (!user || !ok) {
      return res.status(401).json({ status: 'error', message: 'That email and password do not match.' });
    }
    if (user.status !== 'active') {
      return res.status(403).json({ status: 'error', message: 'This account is suspended. Contact support.' });
    }

    auth.issueSession(res, user);
    res.json({ status: 'success', data: { role: user.role } });
  } catch (err) {
    next(err);
  }
});

router.post('/logout', (req, res) => {
  auth.clearSession(res);
  res.json({ status: 'success' });
});

router.get('/session', (req, res) => {
  const user = auth.currentUser(req);
  if (!user) return res.status(401).json({ status: 'error', message: 'Not signed in.' });
  res.json({ status: 'success', data: user });
});

module.exports = router;
