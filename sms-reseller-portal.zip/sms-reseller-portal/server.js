'use strict';

require('dotenv').config();

const path = require('path');
const express = require('express');
const cookieParser = require('cookie-parser');

const { settings } = require('./src/db');
const auth = require('./src/auth');
const dispatch = require('./src/dispatch');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const PUBLIC_DIR = path.join(__dirname, 'public');

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(express.json({ limit: '256kb' }));
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

// Defaults on first boot; the admin can change these under Settings.
const DEFAULTS = {
  brand_name: process.env.BRAND_NAME || 'Lankalink SMS',
  default_rate: process.env.DEFAULT_RATE || '1.10',
  signup_bonus: process.env.SIGNUP_BONUS || '10',
  support_email: process.env.SUPPORT_EMAIL || 'support@example.lk',
  currency: 'LKR',
};
for (const [key, value] of Object.entries(DEFAULTS)) {
  if (settings.get(key) == null) settings.set(key, value);
}

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('X-Frame-Options', 'DENY');
  next();
});

/* ----------------------------------------------------------------- routes */

app.get('/healthz', (req, res) => res.json({ status: 'success', uptime: process.uptime() }));

app.get('/config', (req, res) => {
  const all = settings.all();
  res.json({
    status: 'success',
    data: {
      brand_name: all.brand_name,
      default_rate: Number(all.default_rate),
      signup_bonus: Number(all.signup_bonus),
      support_email: all.support_email,
      currency: all.currency,
    },
  });
});

app.use('/auth', require('./src/routes/auth.routes'));
app.use('/app', require('./src/routes/app.routes'));
app.use('/admin', require('./src/routes/admin.routes'));
app.use('/api/v3', require('./src/routes/api.routes'));

/* ------------------------------------------------------------------ pages */

const page = (file) => (req, res) => res.sendFile(path.join(PUBLIC_DIR, file));

app.get('/', page('index.html'));
app.get('/docs', page('docs.html'));
app.get('/login', page('login.html'));
app.get('/register', page('login.html'));

// Server-side guards so a signed-out visitor never sees dashboard chrome.
app.get('/dashboard', (req, res) => {
  const user = auth.currentUser(req);
  if (!user) return res.redirect('/login?next=/dashboard');
  res.sendFile(path.join(PUBLIC_DIR, 'dashboard.html'));
});

app.get('/console', (req, res) => {
  const user = auth.currentUser(req);
  if (!user) return res.redirect('/login?next=/console');
  if (user.role !== 'admin') return res.redirect('/dashboard');
  res.sendFile(path.join(PUBLIC_DIR, 'admin.html'));
});

app.use(express.static(PUBLIC_DIR, { extensions: ['html'], maxAge: '1h' }));

/* ------------------------------------------------------------- fallbacks */

app.use((req, res) => {
  if (req.path.startsWith('/api/') || req.path.startsWith('/app/') || req.path.startsWith('/admin/')) {
    return res.status(404).json({ status: 'error', message: 'No such endpoint.' });
  }
  res.status(404).sendFile(path.join(PUBLIC_DIR, '404.html'));
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('[error]', err);
  const wantsJson = req.path.startsWith('/api/') || req.path.startsWith('/app/') || req.path.startsWith('/admin/') || req.path.startsWith('/auth/');
  if (wantsJson) {
    return res.status(500).json({ status: 'error', message: 'Something went wrong on our side.' });
  }
  res.status(500).send('Something went wrong on our side.');
});

/* ---------------------------------------------------------------- startup */

if (require.main === module) {
  if (!process.env.SESSION_SECRET) {
    console.error('\nSESSION_SECRET is missing. Copy .env.example to .env and fill it in.\n');
    process.exit(1);
  }

  app.listen(PORT, () => {
    console.log(`${settings.get('brand_name')} running on http://localhost:${PORT}`);
    if (!process.env.TEXTLK_API_TOKEN) {
      console.warn('TEXTLK_API_TOKEN is not set — sending will fail until you add it.');
    }
  });

  // Poll delivery status; Text.lk v3 publishes no delivery webhook.
  const interval = Number(process.env.SYNC_INTERVAL_MS || 60000);
  if (interval > 0) {
    setInterval(() => {
      dispatch.syncStatuses(25).catch((err) => console.warn('[sync]', err.message));
    }, interval).unref();
  }
}

module.exports = app;
