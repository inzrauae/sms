'use strict';

/**
 * First-run setup. Creates the admin account, and optionally a demo customer
 * with an approved sender name so you can click around before wiring up
 * a real Text.lk token.
 *
 *   node scripts/seed.js admin@yourcompany.lk "Strong passphrase here"
 *   node scripts/seed.js admin@yourcompany.lk "Strong passphrase here" --demo
 */

require('dotenv').config();

const readline = require('readline');
const { db, uid, settings, adjustCredits } = require('../src/db');
const auth = require('../src/auth');

async function ask(question, muted = false) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  if (muted) {
    rl._writeToOutput = function (text) {
      if (rl.stdoutMuted && text !== `${question}`) rl.output.write('*');
      else rl.output.write(text);
    };
  }
  const answer = await new Promise((resolve) => {
    rl.question(question, (value) => {
      rl.stdoutMuted = false;
      resolve(value);
    });
    rl.stdoutMuted = muted;
  });
  rl.close();
  if (muted) process.stdout.write('\n');
  return answer.trim();
}

async function main() {
  const args = process.argv.slice(2).filter((a) => !a.startsWith('--'));
  const withDemo = process.argv.includes('--demo');

  const email = (args[0] || (await ask('Admin email: '))).toLowerCase();
  const password = args[1] || (await ask('Admin password (8+ characters): ', true));

  if (!email.includes('@')) {
    console.error('That does not look like an email address.');
    process.exit(1);
  }
  if (password.length < 8) {
    console.error('Use a password of at least 8 characters.');
    process.exit(1);
  }

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) {
    db.prepare("UPDATE users SET role = 'admin', password_hash = ? WHERE id = ?").run(
      await auth.hashPassword(password),
      existing.id
    );
    console.log(`Updated ${email} — now an admin with the new password.`);
  } else {
    const result = db
      .prepare(
        `INSERT INTO users (uid, name, email, password_hash, role, rate, credits)
         VALUES (?, ?, ?, ?, 'admin', ?, 0)`
      )
      .run(uid(), 'Portal admin', email, await auth.hashPassword(password), Number(settings.get('default_rate', '1.10')));
    console.log(`Created admin ${email} (id ${result.lastInsertRowid}).`);
  }

  if (withDemo) {
    const demoEmail = 'demo@example.lk';
    let demo = db.prepare('SELECT * FROM users WHERE email = ?').get(demoEmail);

    if (!demo) {
      const result = db
        .prepare(
          `INSERT INTO users (uid, name, company, email, phone, password_hash, rate)
           VALUES (?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          uid(),
          'Nimal Perera',
          'Ceylon Spice Traders',
          demoEmail,
          '94712345678',
          await auth.hashPassword('demo12345'),
          0.88
        );
      demo = db.prepare('SELECT * FROM users WHERE id = ?').get(result.lastInsertRowid);
      adjustCredits(demo.id, 2500, { type: 'topup', note: 'Demo credits', actor: 'seed' });
    }

    db.prepare(
      `INSERT OR IGNORE INTO sender_ids (user_id, mask, status, note)
       VALUES (?, 'SpiceLK', 'approved', 'Approved for the demo')`
    ).run(demo.id);

    console.log(`Demo customer ready — ${demoEmail} / demo12345 with 2500 credits.`);
  }

  console.log('\nStart the server with: npm start');
}

main().catch((err) => {
  console.error(err.message);
  process.exit(1);
});
